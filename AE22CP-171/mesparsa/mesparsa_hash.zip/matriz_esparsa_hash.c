#include <stdio.h>

#include "lista/list.h"

#define CAPACIDADE 10

#define MSIZE 10e8


int h(long i, long j)
{
	return (MSIZE * i + j) % CAPACIDADE;
}


// Tratamento de colisões por encadeamento.
// Elementos com chaves repetidas não são inseridos.
int inserir(Lista* tabela_hash[], long i, long j, float valor)
{
	int hash_ra = h(i,j);
	
	Item* curr = tabela_hash[hash_ra]->inicio; 
	
	// Não insere itens com chaves repetidas!
	while (curr != NULL) {
		if (curr->i == i && curr->j == j) 
			return -1;
		curr = curr->prox;		
	}
	
	inserirInicio(tabela_hash[hash_ra], novoItem(i, j, valor));
		
	return 1;
}

int main()
{

	Lista* tabela_hash[CAPACIDADE];
	
	for (int i = 0; i < CAPACIDADE; i++)
	{
		tabela_hash[i] = novaLista();
	}
	

	inserir(tabela_hash, 9999999, 1, 3.5);
	inserir(tabela_hash, 1111111, 2, 5.4);
	inserir(tabela_hash, 9999999, 8, 1.5);
	inserir(tabela_hash, 9999999, 3, 0.5);
	

	for (int i = 0; i < CAPACIDADE; i++)
	{
		printf("%d:", i);
		printLista(tabela_hash[i]);
	}
}
